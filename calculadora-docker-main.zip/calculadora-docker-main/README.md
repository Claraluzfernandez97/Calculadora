# Calculadora con historial: Flask, PostgreSQL y Docker Compose

## Requisitos

- Docker Desktop en Windows/macOS, o Docker Engine y Docker Compose en Linux.
- En el servidor, acceso para ejecutar Docker Compose y permitir el puerto web que se vaya a usar.

## Preparar el entorno

En PowerShell, desde esta carpeta:

```powershell
Copy-Item .env.example .env
notepad .env
```

`.env` contiene la configuración de la base y los secretos. En tu equipo local puedes conservar los valores de ejemplo para seguir usando la base creada anteriormente. **Antes de desplegar en un servidor, cambia `DB_PASSWORD` y `SECRET_KEY` por valores largos, privados y diferentes. No compartas ni subas `.env`; copia `.env.example` y crea un `.env` nuevo en el servidor.**

## Iniciar la aplicación

```powershell
docker compose up --build -d
docker compose ps
```

Abre `http://localhost:5000` localmente. En el servidor, usa `http://IP-DEL-SERVIDOR:5000` si su firewall permite el puerto 5000 desde tu red.

## Cómo se conectan los componentes

1. El navegador se conecta al puerto 5000 publicado por el contenedor `app`.
2. Flask, servido por Gunicorn, se conecta a PostgreSQL usando el host `db` y el puerto interno `5432`. `db` es el nombre del servicio de PostgreSQL en Compose; no se debe reemplazar por `localhost` dentro de la app.
3. PostgreSQL almacena sus archivos en el volumen Docker `datos_postgres`. `docker compose down` conserva el volumen; `docker compose down -v` lo borra.
4. El puerto PostgreSQL `5433` está publicado solo en la interfaz local del servidor (`127.0.0.1`) para administración con pgAdmin. En el propio equipo que ejecuta Compose, pgAdmin usa host `127.0.0.1`, puerto `5433`, base `calculadora` y las credenciales de `.env`. Para pgAdmin en otra computadora, usa un túnel SSH; no publiques PostgreSQL directamente a Internet.

La app crea la tabla `operaciones` al arrancar. Para ver su contenido en el Query Tool de pgAdmin, conectado a la base correcta, ejecuta:

```sql
SELECT * FROM operaciones;
```

## Actualizar, revisar y detener

```powershell
docker compose up --build -d
docker compose logs -f app db
docker compose down
```

No uses `docker compose down -v` si quieres conservar el historial.

## Nota para el despliegue

El servidor debe tener Docker y el complemento Docker Compose. Configura su firewall para que solo las redes autorizadas accedan al puerto 5000. Si la aplicación se ofrecerá fuera de una red privada, colócala detrás de un proxy inverso con HTTPS. Mantén `.env` privado y usa contraseñas distintas a las de ejemplo.
