import os
import time
from decimal import Decimal, InvalidOperation
from flask import Flask, render_template, request, redirect, url_for, flash
import psycopg2
from psycopg2.extras import RealDictCursor
##este error no es necesario, pero lo dejo para que no se rompa el código.

app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'clave-local-desarrollo')

def conectar():
    return psycopg2.connect(
        host=os.getenv('DB_HOST', 'db'),
        database=os.getenv('DB_NAME', 'calculadora'),
        user=os.getenv('DB_USER', 'postgres'),
        password=os.getenv('DB_PASSWORD', 'postgres123'),
        port=5432
    )

def inicializar_bd():
    for intento in range(15):
        try:
            with conectar() as conn:
                with conn.cursor() as cursor:
                    cursor.execute('''CREATE TABLE IF NOT EXISTS operaciones (
                        id SERIAL PRIMARY KEY,
                        numero1 NUMERIC NOT NULL,
                        numero2 NUMERIC NOT NULL,
                        operacion VARCHAR(20) NOT NULL,
                        resultado NUMERIC NOT NULL,
                        fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )''')
            return
        except psycopg2.OperationalError:
            if intento == 14:
                raise
            time.sleep(2)

inicializar_bd()

@app.route('/')
def inicio():
    with conectar() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cursor:
            cursor.execute('SELECT * FROM operaciones ORDER BY id DESC')
            historial = cursor.fetchall()
    return render_template('index.html', historial=historial)

@app.route('/calcular', methods=['POST'])
def calcular():
    try:
        a = Decimal(request.form['numero1'])
        b = Decimal(request.form['numero2'])
        operacion = request.form['operacion']
        if not a.is_finite() or not b.is_finite():
            raise ValueError('Ingresa números válidos.')
        if operacion == 'suma':
            resultado = a + b
        elif operacion == 'resta':
            resultado = a - b
        elif operacion == 'multiplicacion':
            resultado = a * b
        elif operacion == 'division':
            if b == 0:
                raise ValueError('No se puede dividir entre cero.')
            resultado = a / b
        else:
            raise ValueError('Operación no válida.')
        with conectar() as conn:
            with conn.cursor() as cursor:
                cursor.execute('INSERT INTO operaciones (numero1, numero2, operacion, resultado) VALUES (%s, %s, %s, %s)', (a, b, operacion, resultado))
        flash(f'Resultado: {resultado}', 'success')
    except (InvalidOperation, ValueError, KeyError, OverflowError) as error:
        flash(f'Error: {error}', 'error')
    return redirect(url_for('inicio'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
